import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { CheckCircle, Award, Users, MapPin } from 'lucide-react';

const highlights = [
  'Experienced and verified professional drivers',
  'On-time delivery guarantee across all routes',
  'Safe and secure handling of all cargo types',
  'Real-time GPS tracking for every shipment',
  'Serving Tamil Nadu, Karnataka, and 15+ states',
  '24/7 customer support and assistance',
];

const stats = [
  { icon: Award, value: '10+', label: 'Years Experience' },
  { icon: Users, value: '5000+', label: 'Happy Clients' },
  { icon: MapPin, value: '15+', label: 'States Covered' },
  { icon: CheckCircle, value: '99.2%', label: 'On-Time Rate' },
];

export default function About() {
  const { ref, visible } = useIntersectionObserver();

  return (
    <section id="about" className="py-20 lg:py-28 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image side */}
          <div
            className={`relative transition-all duration-700 ${
              visible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
            }`}
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/2199293/pexels-photo-2199293.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="SVR Transport fleet"
                className="w-full h-80 lg:h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-900/60 to-transparent" />
            </div>

            {/* Floating card */}
            <div className="absolute -bottom-6 -right-6 bg-white rounded-2xl shadow-2xl p-6 max-w-48">
              <div className="text-3xl font-display font-bold text-orange-500">10K+</div>
              <div className="text-navy-700 font-semibold text-sm mt-1">Successful Deliveries</div>
              <div className="flex -space-x-2 mt-3">
                {[
                  'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=60',
                  'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=60',
                  'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=60',
                ].map((src, i) => (
                  <img key={i} src={src} alt="" className="w-8 h-8 rounded-full border-2 border-white object-cover" />
                ))}
                <div className="w-8 h-8 rounded-full border-2 border-white bg-orange-500 flex items-center justify-center text-white text-xs font-bold">+</div>
              </div>
            </div>

            {/* Accent decoration */}
            <div className="absolute -top-4 -left-4 w-24 h-24 bg-orange-500/10 rounded-full border-2 border-orange-500/20" />
            <div className="absolute top-8 -left-8 w-12 h-12 bg-orange-500/20 rounded-full" />
          </div>

          {/* Text side */}
          <div
            className={`transition-all duration-700 delay-200 ${
              visible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
            }`}
          >
            <div className="inline-block bg-orange-100 text-orange-600 text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
              About SVR TRANSPORT
            </div>
            <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-navy-900 leading-tight mb-6">
              India's Trusted{' '}
              <span className="text-orange-500">Logistics</span>{' '}
              Partner
            </h2>
            <p className="text-gray-600 text-lg leading-relaxed mb-6">
              SVR TRANSPORT is a leading transport and logistics company based in Tamil Nadu, India.
              We provide comprehensive freight and logistics solutions to businesses of all sizes —
              from small enterprises to large corporations across the country.
            </p>
            <p className="text-gray-600 leading-relaxed mb-8">
              With a dedicated fleet of trucks, experienced drivers, and a commitment to excellence,
              we ensure your goods reach their destination safely and on time. Our customer-first approach
              has made us one of the most trusted names in South Indian logistics.
            </p>

            {/* Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-10">
              {highlights.map((item) => (
                <div key={item} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700 text-sm">{item}</span>
                </div>
              ))}
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {stats.map(({ icon: Icon, value, label }) => (
                <div key={label} className="text-center p-4 bg-navy-50 rounded-xl">
                  <Icon className="w-6 h-6 text-orange-500 mx-auto mb-2" />
                  <div className="font-display font-bold text-xl text-navy-900">{value}</div>
                  <div className="text-gray-500 text-xs mt-1">{label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
