import { useState } from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { MapPin, Navigation, Package, Weight, Truck, Phone, CheckCircle } from 'lucide-react';

const vehicleTypes = [
  'Small Pickup (3-5 tons)',
  '14ft Truck (7-9 tons)',
  '17ft Truck (10-12 tons)',
  '19ft Truck (13-15 tons)',
  '20ft Open Truck (15-18 tons)',
  '32ft Container (20-25 tons)',
];

const materialTypes = [
  'General Goods',
  'Industrial Equipment',
  'Construction Materials',
  'Agricultural Products',
  'Electronics & Appliances',
  'Furniture & Household',
  'Chemicals (Non-Hazardous)',
  'Other',
];

export default function Booking() {
  const { ref, visible } = useIntersectionObserver();
  const [form, setForm] = useState({
    pickup: '',
    drop: '',
    material: '',
    weight: '',
    vehicle: '',
    phone: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1200));
    setLoading(false);
    setSubmitted(true);
  };

  return (
    <section id="booking" className="py-20 lg:py-28 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left info */}
          <div
            className={`transition-all duration-700 ${
              visible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
            }`}
          >
            <div className="inline-block bg-orange-100 text-orange-600 text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
              Load Booking
            </div>
            <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-navy-900 leading-tight mb-6">
              Book Your{' '}
              <span className="text-orange-500">Shipment</span>{' '}
              Today
            </h2>
            <p className="text-gray-600 text-lg leading-relaxed mb-10">
              Fill out the booking form and our team will get back to you within 30 minutes
              with a competitive quote and vehicle availability.
            </p>

            {/* Steps */}
            {[
              { num: '01', title: 'Fill the Form', desc: 'Enter pickup, drop, and cargo details' },
              { num: '02', title: 'Get a Quote', desc: 'Receive instant pricing from our team' },
              { num: '03', title: 'Confirm & Ship', desc: 'Confirm the booking and track live' },
            ].map((step, i) => (
              <div
                key={step.num}
                className="flex gap-4 mb-6"
                style={{ transitionDelay: `${i * 100 + 200}ms` }}
              >
                <div className="flex-shrink-0 w-12 h-12 bg-orange-500 text-white font-display font-bold text-lg rounded-xl flex items-center justify-center">
                  {step.num}
                </div>
                <div>
                  <div className="font-semibold text-navy-900">{step.title}</div>
                  <div className="text-gray-500 text-sm mt-1">{step.desc}</div>
                </div>
              </div>
            ))}

            {/* Contact quick links */}
            <div className="mt-8 p-6 bg-navy-50 rounded-2xl">
              <p className="text-navy-700 font-semibold mb-3">Need immediate assistance?</p>
              <a
                href="tel:+919384756299"
                className="flex items-center gap-2 text-orange-500 font-semibold hover:underline"
              >
                <Phone className="w-5 h-5" />
                +91 93847 56299
              </a>
            </div>
          </div>

          {/* Form */}
          <div
            className={`transition-all duration-700 delay-200 ${
              visible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
            }`}
          >
            {submitted ? (
              <div className="bg-green-50 border border-green-200 rounded-2xl p-12 text-center">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="font-display font-bold text-2xl text-navy-900 mb-3">Booking Request Sent!</h3>
                <p className="text-gray-600 mb-6">
                  Our team will contact you within 30 minutes with availability and pricing.
                </p>
                <button
                  onClick={() => { setSubmitted(false); setForm({ pickup: '', drop: '', material: '', weight: '', vehicle: '', phone: '' }); }}
                  className="bg-orange-500 text-white font-semibold px-8 py-3 rounded-xl hover:bg-orange-400 transition-colors"
                >
                  Book Another
                </button>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="bg-white border border-gray-100 shadow-xl rounded-2xl p-8 space-y-5"
              >
                <h3 className="font-display font-bold text-xl text-navy-900 mb-2">Booking Details</h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {/* Pickup */}
                  <div className="relative">
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Pickup Location *</label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-orange-400" />
                      <input
                        name="pickup"
                        value={form.pickup}
                        onChange={handleChange}
                        required
                        placeholder="e.g. Chennai, TN"
                        className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent text-sm"
                      />
                    </div>
                  </div>

                  {/* Drop */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Drop Location *</label>
                    <div className="relative">
                      <Navigation className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-orange-400" />
                      <input
                        name="drop"
                        value={form.drop}
                        onChange={handleChange}
                        required
                        placeholder="e.g. Bangalore, KA"
                        className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent text-sm"
                      />
                    </div>
                  </div>
                </div>

                {/* Material */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Material Type *</label>
                  <div className="relative">
                    <Package className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-orange-400 pointer-events-none" />
                    <select
                      name="material"
                      value={form.material}
                      onChange={handleChange}
                      required
                      className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent text-sm appearance-none bg-white"
                    >
                      <option value="">Select material type</option>
                      {materialTypes.map((m) => <option key={m} value={m}>{m}</option>)}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  {/* Weight */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Weight (Tons) *</label>
                    <div className="relative">
                      <Weight className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-orange-400" />
                      <input
                        name="weight"
                        value={form.weight}
                        onChange={handleChange}
                        required
                        type="number"
                        min="0.1"
                        step="0.1"
                        placeholder="e.g. 5"
                        className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent text-sm"
                      />
                    </div>
                  </div>

                  {/* Vehicle */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">Vehicle Type *</label>
                    <div className="relative">
                      <Truck className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-orange-400 pointer-events-none" />
                      <select
                        name="vehicle"
                        value={form.vehicle}
                        onChange={handleChange}
                        required
                        className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent text-sm appearance-none bg-white"
                      >
                        <option value="">Select vehicle type</option>
                        {vehicleTypes.map((v) => <option key={v} value={v}>{v}</option>)}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone Number *</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-orange-400" />
                    <input
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      required
                      type="tel"
                      placeholder="+91 XXXXX XXXXX"
                      pattern="[0-9+\s-]{10,15}"
                      className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent text-sm"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-orange-500 hover:bg-orange-400 disabled:bg-orange-300 text-white font-bold py-4 rounded-xl text-lg transition-all duration-200 hover:shadow-xl hover:shadow-orange-500/30 flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <>
                      <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Processing...
                    </>
                  ) : (
                    'Submit Booking Request'
                  )}
                </button>

                <p className="text-center text-xs text-gray-400">
                  By submitting, you agree to be contacted by SVR TRANSPORT for this booking.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
