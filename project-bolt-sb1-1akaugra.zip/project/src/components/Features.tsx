import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { MapPin, Headphones, Zap, ShieldCheck, Package, Tag } from 'lucide-react';

const features = [
  {
    icon: MapPin,
    title: 'Live GPS Tracking',
    desc: 'Track your shipment in real-time with accurate GPS updates at every milestone.',
    color: 'text-blue-500',
    bg: 'bg-blue-50',
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    desc: 'Round-the-clock customer support to assist you anytime, any day of the year.',
    color: 'text-green-500',
    bg: 'bg-green-50',
  },
  {
    icon: Zap,
    title: 'Fast Delivery',
    desc: 'Express delivery options ensuring your cargo reaches the destination ahead of time.',
    color: 'text-orange-500',
    bg: 'bg-orange-50',
  },
  {
    icon: ShieldCheck,
    title: 'Verified Drivers',
    desc: 'All drivers are background-verified, licensed, and trained for professional service.',
    color: 'text-red-500',
    bg: 'bg-red-50',
  },
  {
    icon: Package,
    title: 'Secure Goods Handling',
    desc: 'Professional loading, unloading, and handling ensuring your goods stay damage-free.',
    color: 'text-teal-500',
    bg: 'bg-teal-50',
  },
  {
    icon: Tag,
    title: 'Affordable Pricing',
    desc: 'Competitive, transparent pricing with no hidden charges for all transport routes.',
    color: 'text-amber-500',
    bg: 'bg-amber-50',
  },
];

export default function Features() {
  const { ref, visible } = useIntersectionObserver();

  return (
    <section className="py-20 lg:py-28 bg-navy-900" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="inline-block bg-orange-500/20 border border-orange-500/30 text-orange-300 text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
            Why Choose Us
          </div>
          <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-white leading-tight mb-4">
            Built for{' '}
            <span className="text-orange-400">Reliability</span>{' '}
            & Speed
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            We combine technology with logistics expertise to deliver a service
            that businesses across India trust.
          </p>
        </div>

        {/* Features grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map(({ icon: Icon, title, desc, color, bg }, i) => (
            <div
              key={title}
              className={`group bg-white/5 hover:bg-white/10 border border-white/10 hover:border-orange-500/30 rounded-2xl p-8 transition-all duration-300 hover:-translate-y-1 ${
                visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className={`w-14 h-14 ${bg} rounded-2xl flex items-center justify-center mb-5`}>
                <Icon className={`w-7 h-7 ${color}`} />
              </div>
              <h3 className="font-display font-semibold text-xl text-white mb-3">{title}</h3>
              <p className="text-gray-400 leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>

        {/* Banner strip */}
        <div
          className={`mt-16 bg-gradient-to-r from-orange-600 to-orange-500 rounded-2xl p-8 lg:p-12 flex flex-col lg:flex-row items-center justify-between gap-6 transition-all duration-700 delay-500 ${
            visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div>
            <h3 className="font-display font-bold text-2xl lg:text-3xl text-white mb-2">
              Ready to ship your cargo?
            </h3>
            <p className="text-orange-100 text-lg">
              Get an instant quote and book your transport today.
            </p>
          </div>
          <div className="flex gap-4">
            <button
              onClick={() => document.querySelector('#booking')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-white text-orange-600 hover:bg-orange-50 font-bold px-8 py-4 rounded-xl text-lg transition-all duration-200 hover:shadow-xl whitespace-nowrap"
            >
              Book Now
            </button>
            <a
              href="tel:+919384756299"
              className="bg-orange-700/50 hover:bg-orange-700 text-white border border-white/30 font-semibold px-8 py-4 rounded-xl text-lg transition-all duration-200 whitespace-nowrap"
            >
              Call Us
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
