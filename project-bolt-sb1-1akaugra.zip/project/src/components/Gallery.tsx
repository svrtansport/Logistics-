import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

const images = [
  {
    src: 'https://images.pexels.com/photos/1427541/pexels-photo-1427541.jpeg?auto=compress&cs=tinysrgb&w=800',
    label: 'Highway Transport',
    span: 'col-span-2 row-span-2',
  },
  {
    src: 'https://images.pexels.com/photos/2199293/pexels-photo-2199293.jpeg?auto=compress&cs=tinysrgb&w=600',
    label: 'Fleet Operations',
    span: '',
  },
  {
    src: 'https://images.pexels.com/photos/906494/pexels-photo-906494.jpeg?auto=compress&cs=tinysrgb&w=600',
    label: 'Loading & Unloading',
    span: '',
  },
  {
    src: 'https://images.pexels.com/photos/1267338/pexels-photo-1267338.jpeg?auto=compress&cs=tinysrgb&w=600',
    label: 'Warehouse Operations',
    span: '',
  },
  {
    src: 'https://images.pexels.com/photos/378570/pexels-photo-378570.jpeg?auto=compress&cs=tinysrgb&w=600',
    label: 'Long-Haul Delivery',
    span: '',
  },
  {
    src: 'https://images.pexels.com/photos/2199293/pexels-photo-2199293.jpeg?auto=compress&cs=tinysrgb&w=600',
    label: 'Driver Team',
    span: '',
  },
];

export default function Gallery() {
  const { ref, visible } = useIntersectionObserver();

  return (
    <section className="py-20 lg:py-28 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          className={`text-center mb-14 transition-all duration-700 ${
            visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="inline-block bg-orange-100 text-orange-600 text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
            Gallery
          </div>
          <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-navy-900 leading-tight mb-4">
            Our Fleet &{' '}
            <span className="text-orange-500">Operations</span>
          </h2>
          <p className="text-gray-600 text-lg max-w-xl mx-auto">
            A glimpse into SVR TRANSPORT's fleet, loading operations, and nationwide delivery network.
          </p>
        </div>

        {/* Masonry-style grid */}
        <div
          className={`grid grid-cols-2 lg:grid-cols-4 gap-4 transition-all duration-700 delay-100 ${
            visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {images.map((img, i) => (
            <div
              key={i}
              className={`relative overflow-hidden rounded-2xl group cursor-pointer ${img.span} ${i === 0 ? 'hidden lg:block' : ''}`}
            >
              <img
                src={img.src}
                alt={img.label}
                className="w-full h-48 lg:h-full object-cover group-hover:scale-105 transition-transform duration-500"
                style={{ minHeight: i === 0 ? '320px' : '200px' }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-900/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                <span className="text-white font-semibold">{img.label}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
