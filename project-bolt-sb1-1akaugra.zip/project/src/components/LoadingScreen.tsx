import { useEffect, useState } from 'react';
import { Truck } from 'lucide-react';

export default function LoadingScreen() {
  const [progress, setProgress] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(interval);
          setTimeout(() => setDone(true), 300);
          return 100;
        }
        return p + Math.random() * 15 + 5;
      });
    }, 120);
    return () => clearInterval(interval);
  }, []);

  if (done) return null;

  return (
    <div
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center transition-opacity duration-500 ${
        progress >= 100 ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{ background: 'linear-gradient(135deg, #060d1a 0%, #0a1528 50%, #1e3668 100%)' }}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 mb-12">
        <div className="bg-orange-500 p-3 rounded-xl animate-pulse">
          <Truck className="w-10 h-10 text-white" />
        </div>
        <div>
          <div className="font-display font-bold text-3xl text-white tracking-wider">SVR</div>
          <div className="font-display font-bold text-3xl text-orange-400 tracking-wider -mt-1">TRANSPORT</div>
        </div>
      </div>

      {/* Truck animation */}
      <div className="relative w-64 mb-8 overflow-hidden">
        <div className="text-4xl" style={{ animation: 'loadTruck 1.5s ease-in-out infinite alternate' }}>
          🚛
        </div>
        <style>{`
          @keyframes loadTruck {
            0% { transform: translateX(0); }
            100% { transform: translateX(180px); }
          }
        `}</style>
      </div>

      {/* Progress bar */}
      <div className="w-64">
        <div className="flex justify-between text-xs text-gray-400 mb-2">
          <span>Loading</span>
          <span>{Math.min(Math.round(progress), 100)}%</span>
        </div>
        <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-orange-500 rounded-full transition-all duration-200"
            style={{ width: `${Math.min(progress, 100)}%` }}
          />
        </div>
      </div>

      <p className="text-gray-400 text-sm mt-6">Fast, Safe &amp; Reliable Transport</p>
    </div>
  );
}
