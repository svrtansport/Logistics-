import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import {
  Package,
  Truck,
  Container,
  Zap,
  Factory,
  MapPin,
  Clock,
  Settings,
} from 'lucide-react';

const services = [
  {
    icon: Truck,
    title: 'Full Load Transport',
    desc: 'Dedicated full truck load service for large shipments with door-to-door delivery across India.',
    tag: 'FTL',
  },
  {
    icon: Package,
    title: 'Part Load Service',
    desc: 'Cost-effective part load transportation sharing truck space for smaller consignments.',
    tag: 'LTL',
  },
  {
    icon: Container,
    title: '20ft Open Truck',
    desc: 'Specialized 20-foot open truck service ideal for oversized and heavy industrial cargo.',
    tag: 'Heavy',
  },
  {
    icon: Settings,
    title: '14ft / 17ft / 19ft Vehicle',
    desc: 'Multi-size fleet options — 14ft, 17ft, and 19ft trucks for versatile freight needs.',
    tag: 'Multi-Size',
  },
  {
    icon: Factory,
    title: 'Industrial Goods Transport',
    desc: 'Specialized handling and transport of industrial equipment and manufacturing goods safely.',
    tag: 'Industrial',
  },
  {
    icon: MapPin,
    title: 'TN to Karnataka Route',
    desc: 'Regular scheduled runs from Tamil Nadu to Karnataka with guaranteed slot availability.',
    tag: 'Inter-State',
  },
  {
    icon: Zap,
    title: 'Express Delivery',
    desc: 'Priority express delivery service with fastest turnaround times and real-time tracking.',
    tag: 'Express',
  },
  {
    icon: Clock,
    title: 'Fleet Management',
    desc: 'Complete fleet management solutions for businesses requiring dedicated transport capacity.',
    tag: 'Managed',
  },
];

export default function Services() {
  const { ref, visible } = useIntersectionObserver();

  return (
    <section id="services" className="py-20 lg:py-28 bg-gray-50" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          className={`text-center mb-16 transition-all duration-700 ${
            visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="inline-block bg-orange-100 text-orange-600 text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
            Our Services
          </div>
          <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-navy-900 leading-tight mb-4">
            Complete{' '}
            <span className="text-orange-500">Logistics</span>{' '}
            Solutions
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            From single consignments to large fleet requirements, we provide end-to-end
            transport solutions tailored to your business needs.
          </p>
        </div>

        {/* Cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map(({ icon: Icon, title, desc, tag }, i) => (
            <div
              key={title}
              className={`group bg-white rounded-2xl p-6 shadow-sm hover:shadow-xl border border-gray-100 hover:border-orange-200 transition-all duration-300 hover:-translate-y-1 cursor-default ${
                visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              {/* Icon */}
              <div className="relative mb-5">
                <div className="w-14 h-14 bg-navy-50 group-hover:bg-orange-500 rounded-2xl flex items-center justify-center transition-colors duration-300">
                  <Icon className="w-7 h-7 text-navy-700 group-hover:text-white transition-colors duration-300" />
                </div>
                <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                  {tag}
                </span>
              </div>

              <h3 className="font-display font-semibold text-lg text-navy-900 mb-3 group-hover:text-orange-500 transition-colors">
                {title}
              </h3>
              <p className="text-gray-500 text-sm leading-relaxed">{desc}</p>

              {/* Arrow */}
              <div className="mt-4 flex items-center gap-1 text-orange-500 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                Learn more
                <span className="transform group-hover:translate-x-1 transition-transform">→</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
