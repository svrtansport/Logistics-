import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Prakash Venkataraman',
    role: 'Operations Manager',
    company: 'SunTech Industries, Chennai',
    avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=120',
    rating: 5,
    text:
      'SVR TRANSPORT has been our logistics partner for 3 years. Their on-time delivery rate is exceptional and the real-time tracking feature gives us full visibility. Highly recommended for industrial goods transport.',
  },
  {
    name: 'Meena Krishnamurthy',
    role: 'Supply Chain Head',
    company: 'Agri Exports Ltd, Coimbatore',
    avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=120',
    rating: 5,
    text:
      'We needed reliable transport from Tamil Nadu to Karnataka on short notice and SVR delivered. Professional drivers, well-maintained trucks, and transparent pricing. Our go-to transport company.',
  },
  {
    name: 'Aravind Subramanian',
    role: 'Logistics Director',
    company: 'Shree Builders, Madurai',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=120',
    rating: 5,
    text:
      "The 20ft open truck service is perfect for our construction materials. SVR's team is responsive, the booking process is seamless, and they always deliver without damage. Outstanding service quality.",
  },
];

export default function Testimonials() {
  const { ref, visible } = useIntersectionObserver();

  return (
    <section className="py-20 lg:py-28 bg-navy-950" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          className={`text-center mb-14 transition-all duration-700 ${
            visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="inline-block bg-orange-500/20 border border-orange-500/30 text-orange-300 text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
            Testimonials
          </div>
          <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-white leading-tight mb-4">
            What Our Clients{' '}
            <span className="text-orange-400">Say</span>
          </h2>
          <p className="text-gray-400 text-lg max-w-xl mx-auto">
            Trusted by hundreds of businesses across Tamil Nadu and South India.
          </p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className={`bg-white/5 border border-white/10 hover:border-orange-500/30 rounded-2xl p-8 transition-all duration-300 hover:-translate-y-1 ${
                visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              {/* Quote icon */}
              <Quote className="w-8 h-8 text-orange-500/40 mb-4" />

              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(t.rating)].map((_, j) => (
                  <Star key={j} className="w-4 h-4 text-orange-400 fill-orange-400" />
                ))}
              </div>

              {/* Review */}
              <p className="text-gray-300 leading-relaxed mb-6 text-sm">"{t.text}"</p>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t border-white/10">
                <img
                  src={t.avatar}
                  alt={t.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-orange-500/30"
                />
                <div>
                  <div className="text-white font-semibold text-sm">{t.name}</div>
                  <div className="text-gray-400 text-xs mt-0.5">{t.role}</div>
                  <div className="text-orange-400 text-xs">{t.company}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
