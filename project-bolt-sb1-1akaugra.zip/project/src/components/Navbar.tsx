import { useState, useEffect } from 'react';
import { Menu, X, Truck, Phone } from 'lucide-react';

const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Book Load', href: '#booking' },
  { label: 'Tracking', href: '#tracking' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNav = (href: string) => {
    setOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-navy-900 shadow-2xl' : 'bg-navy-950/90 backdrop-blur-md'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <button
            onClick={() => handleNav('#home')}
            className="flex items-center gap-2 group"
          >
            <div className="bg-orange-500 p-2 rounded-lg group-hover:bg-orange-400 transition-colors">
              <Truck className="w-6 h-6 text-white" />
            </div>
            <div className="leading-tight">
              <span className="text-white font-display font-bold text-xl tracking-wider">SVR</span>
              <span className="text-orange-400 font-display font-bold text-xl tracking-wider"> TRANSPORT</span>
            </div>
          </button>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNav(link.href)}
                className="text-gray-300 hover:text-orange-400 px-4 py-2 text-sm font-medium transition-colors duration-200 relative group"
              >
                {link.label}
                <span className="absolute bottom-1 left-4 right-4 h-0.5 bg-orange-400 scale-x-0 group-hover:scale-x-100 transition-transform duration-200 origin-left" />
              </button>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              href="tel:+919384756299"
              className="flex items-center gap-2 text-gray-300 hover:text-white transition-colors text-sm"
            >
              <Phone className="w-4 h-4 text-orange-400" />
              +91 93847 56299
            </a>
            <button
              onClick={() => handleNav('#booking')}
              className="bg-orange-500 hover:bg-orange-400 text-white font-semibold px-5 py-2.5 rounded-lg text-sm transition-all duration-200 hover:shadow-lg hover:shadow-orange-500/30"
            >
              Book Now
            </button>
          </div>

          {/* Mobile Toggle */}
          <button
            onClick={() => setOpen(!open)}
            className="lg:hidden text-white p-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`lg:hidden transition-all duration-300 overflow-hidden ${
          open ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="bg-navy-900 border-t border-white/10 px-4 py-4 space-y-1">
          {navLinks.map((link) => (
            <button
              key={link.href}
              onClick={() => handleNav(link.href)}
              className="block w-full text-left text-gray-300 hover:text-orange-400 hover:bg-white/5 px-4 py-3 rounded-lg text-sm font-medium transition-colors"
            >
              {link.label}
            </button>
          ))}
          <div className="pt-3 border-t border-white/10 flex flex-col gap-2">
            <a
              href="tel:+919384756299"
              className="flex items-center gap-2 text-gray-300 px-4 py-2 text-sm"
            >
              <Phone className="w-4 h-4 text-orange-400" />
              +91 93847 56299
            </a>
            <button
              onClick={() => handleNav('#booking')}
              className="bg-orange-500 text-white font-semibold px-5 py-3 rounded-lg text-sm w-full"
            >
              Book Now
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
