import { useState } from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { Search, MapPin, Package, Truck, CheckCircle, Clock } from 'lucide-react';

const MOCK_TRACKING = {
  SVR001: {
    id: 'SVR001',
    status: 'In Transit',
    from: 'Chennai, Tamil Nadu',
    to: 'Bangalore, Karnataka',
    driver: 'Rajan Kumar',
    vehicle: 'TN 33 AB 1234',
    eta: 'Today, 6:00 PM',
    weight: '8 Tons',
    steps: [
      { label: 'Order Placed', time: 'May 13, 9:00 AM', done: true },
      { label: 'Picked Up', time: 'May 13, 11:30 AM', done: true },
      { label: 'In Transit', time: 'May 13, 2:00 PM', done: true },
      { label: 'Out for Delivery', time: 'Est. 5:00 PM', done: false },
      { label: 'Delivered', time: 'Est. 6:00 PM', done: false },
    ],
  },
  SVR002: {
    id: 'SVR002',
    status: 'Delivered',
    from: 'Coimbatore, TN',
    to: 'Mysore, Karnataka',
    driver: 'Suresh Babu',
    vehicle: 'TN 44 CD 5678',
    eta: 'Delivered on May 12',
    weight: '12 Tons',
    steps: [
      { label: 'Order Placed', time: 'May 11, 8:00 AM', done: true },
      { label: 'Picked Up', time: 'May 11, 10:00 AM', done: true },
      { label: 'In Transit', time: 'May 11, 1:00 PM', done: true },
      { label: 'Out for Delivery', time: 'May 12, 8:00 AM', done: true },
      { label: 'Delivered', time: 'May 12, 11:00 AM', done: true },
    ],
  },
};

type TrackingData = (typeof MOCK_TRACKING)[keyof typeof MOCK_TRACKING];

export default function Tracking() {
  const { ref, visible } = useIntersectionObserver();
  const [input, setInput] = useState('');
  const [result, setResult] = useState<TrackingData | null | undefined>(undefined);
  const [loading, setLoading] = useState(false);

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1000));
    const found = MOCK_TRACKING[input.toUpperCase() as keyof typeof MOCK_TRACKING];
    setResult(found ?? null);
    setLoading(false);
  };

  return (
    <section id="tracking" className="py-20 lg:py-28 bg-gray-50" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div
          className={`text-center mb-14 transition-all duration-700 ${
            visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="inline-block bg-orange-100 text-orange-600 text-sm font-semibold px-4 py-1.5 rounded-full mb-4">
            Live Tracking
          </div>
          <h2 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-navy-900 leading-tight mb-4">
            Track Your{' '}
            <span className="text-orange-500">Shipment</span>
          </h2>
          <p className="text-gray-600 text-lg max-w-xl mx-auto">
            Enter your shipment ID to get real-time updates on your cargo location and status.
            Try <strong>SVR001</strong> or <strong>SVR002</strong>.
          </p>
        </div>

        {/* Search */}
        <div
          className={`max-w-2xl mx-auto mb-12 transition-all duration-700 delay-100 ${
            visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <form onSubmit={handleTrack} className="flex gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Enter Shipment ID (e.g. SVR001)"
                className="w-full pl-12 pr-4 py-4 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent text-base shadow-sm"
              />
            </div>
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="bg-orange-500 hover:bg-orange-400 disabled:bg-orange-300 text-white font-bold px-8 py-4 rounded-xl transition-all duration-200 flex items-center gap-2 whitespace-nowrap shadow-sm"
            >
              {loading ? (
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <Search className="w-5 h-5" />
              )}
              Track Now
            </button>
          </form>
        </div>

        {/* Result */}
        {result === null && (
          <div className="max-w-2xl mx-auto text-center py-10 text-gray-500">
            <Package className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <p className="text-lg font-medium">Shipment not found</p>
            <p className="text-sm mt-1">Please check your shipment ID and try again.</p>
          </div>
        )}

        {result && (
          <div className="max-w-4xl mx-auto">
            {/* Status card */}
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-8 mb-6">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-8">
                <div>
                  <div className="text-sm text-gray-500 mb-1">Shipment ID</div>
                  <div className="font-display font-bold text-2xl text-navy-900">{result.id}</div>
                </div>
                <div
                  className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold ${
                    result.status === 'Delivered'
                      ? 'bg-green-100 text-green-700'
                      : 'bg-orange-100 text-orange-700'
                  }`}
                >
                  {result.status === 'Delivered' ? (
                    <CheckCircle className="w-4 h-4" />
                  ) : (
                    <Truck className="w-4 h-4" />
                  )}
                  {result.status}
                </div>
              </div>

              {/* Info grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mb-8">
                {[
                  { label: 'From', value: result.from, icon: MapPin },
                  { label: 'To', value: result.to, icon: MapPin },
                  { label: 'ETA', value: result.eta, icon: Clock },
                  { label: 'Vehicle', value: result.vehicle, icon: Truck },
                ].map(({ label, value, icon: Icon }) => (
                  <div key={label}>
                    <div className="flex items-center gap-1 text-xs text-gray-400 mb-1">
                      <Icon className="w-3 h-3" /> {label}
                    </div>
                    <div className="text-sm font-semibold text-navy-900">{value}</div>
                  </div>
                ))}
              </div>

              {/* Progress timeline */}
              <div>
                <h4 className="font-semibold text-navy-800 mb-6 text-sm uppercase tracking-wider">Shipment Progress</h4>
                <div className="relative">
                  {/* Line */}
                  <div className="absolute left-5 top-0 bottom-0 w-0.5 bg-gray-100" />
                  <div
                    className="absolute left-5 top-0 w-0.5 bg-orange-400 transition-all duration-1000"
                    style={{
                      height: `${(result.steps.filter((s) => s.done).length / result.steps.length) * 100}%`,
                    }}
                  />

                  <div className="space-y-6">
                    {result.steps.map((step, i) => (
                      <div key={i} className="flex items-start gap-6 relative">
                        <div
                          className={`relative z-10 w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${
                            step.done
                              ? 'bg-orange-500 text-white'
                              : 'bg-gray-100 text-gray-400 border-2 border-gray-200'
                          }`}
                        >
                          {step.done ? <CheckCircle className="w-5 h-5" /> : <Clock className="w-5 h-5" />}
                        </div>
                        <div className="pt-2">
                          <div
                            className={`font-semibold ${step.done ? 'text-navy-900' : 'text-gray-400'}`}
                          >
                            {step.label}
                          </div>
                          <div className="text-sm text-gray-400 mt-0.5">{step.time}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
