import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Play } from 'lucide-react';

export default function Hero() {
  const truckRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  const handleScroll = (href: string) => {
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, #060d1a 0%, #0a1528 40%, #142447 70%, #1e3668 100%)',
      }}
    >
      {/* Background image overlay */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `url('https://images.pexels.com/photos/1427541/pexels-photo-1427541.jpeg?auto=compress&cs=tinysrgb&w=1920')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-navy-950/80 via-navy-900/60 to-transparent" />

      {/* Road strip at bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-24 overflow-hidden">
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage: `url('https://images.pexels.com/photos/378570/pexels-photo-378570.jpeg?auto=compress&cs=tinysrgb&w=1920')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center bottom',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950 to-transparent" />
        {/* Road markings */}
        <div className="absolute bottom-8 left-0 right-0 h-2 flex items-center gap-8 px-8">
          {[...Array(20)].map((_, i) => (
            <div key={i} className="flex-1 h-1 bg-yellow-400/40 rounded" />
          ))}
        </div>
      </div>

      {/* Animated truck */}
      <div
        ref={truckRef}
        className="absolute bottom-12 text-6xl"
        style={{
          animation: 'truckDrive 14s linear infinite',
          fontSize: '3rem',
          filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.5))',
        }}
      >
        🚛
      </div>

      <style>{`
        @keyframes truckDrive {
          0% { left: -200px; }
          100% { left: 110%; }
        }
      `}</style>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 pt-40">
        <div className="max-w-3xl">
          {/* Badge */}
          <div
            className={`inline-flex items-center gap-2 bg-orange-500/20 border border-orange-500/40 text-orange-300 text-sm font-medium px-4 py-2 rounded-full mb-6 transition-all duration-700 ${
              visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <span className="w-2 h-2 bg-orange-400 rounded-full animate-pulse" />
            Tamil Nadu's Trusted Transport Partner
          </div>

          {/* Heading */}
          <h1
            className={`font-display font-bold text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-white leading-tight mb-6 transition-all duration-700 delay-100 ${
              visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            Fast, Safe &{' '}
            <span className="text-orange-400 relative">
              Reliable
              <span
                className="absolute -bottom-1 left-0 right-0 h-1 bg-orange-400/50 rounded"
                style={{ animation: 'expandWidth 1s ease-out 0.8s forwards', transformOrigin: 'left', transform: 'scaleX(0)' }}
              />
            </span>
            <br />
            Transport Solutions
          </h1>

          <style>{`
            @keyframes expandWidth {
              to { transform: scaleX(1); }
            }
          `}</style>

          {/* Subheading */}
          <p
            className={`text-gray-300 text-lg sm:text-xl leading-relaxed mb-10 max-w-2xl transition-all duration-700 delay-200 ${
              visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            Connecting Businesses Across India with Trusted Logistics Services.
            From Tamil Nadu to every corner of the country — on time, every time.
          </p>

          {/* CTAs */}
          <div
            className={`flex flex-wrap gap-4 mb-14 transition-all duration-700 delay-300 ${
              visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <button
              onClick={() => handleScroll('#booking')}
              className="flex items-center gap-2 bg-orange-500 hover:bg-orange-400 text-white font-semibold px-8 py-4 rounded-xl text-lg transition-all duration-200 hover:shadow-xl hover:shadow-orange-500/40 hover:-translate-y-0.5"
            >
              Book Load
              <ArrowRight className="w-5 h-5" />
            </button>
            <button
              onClick={() => handleScroll('#contact')}
              className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white border border-white/30 font-semibold px-8 py-4 rounded-xl text-lg transition-all duration-200 hover:-translate-y-0.5"
            >
              <Play className="w-5 h-5 text-orange-400" />
              Contact Now
            </button>
          </div>

          {/* Stats */}
          <div
            className={`grid grid-cols-3 gap-6 transition-all duration-700 delay-500 ${
              visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            {[
              { value: '500+', label: 'Vehicles Fleet' },
              { value: '15+', label: 'States Covered' },
              { value: '10K+', label: 'Deliveries Done' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-2xl sm:text-3xl font-display font-bold text-orange-400">{stat.value}</div>
                <div className="text-gray-400 text-sm mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-32 right-8 hidden lg:flex flex-col items-center gap-2">
        <div className="text-gray-500 text-xs writing-mode-vertical rotate-90 mb-2 tracking-widest">SCROLL</div>
        <div className="w-px h-16 bg-gradient-to-b from-gray-500 to-transparent" />
      </div>
    </section>
  );
}
